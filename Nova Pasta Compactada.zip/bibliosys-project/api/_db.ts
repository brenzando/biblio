import { sql } from '@vercel/postgres';

export { sql };